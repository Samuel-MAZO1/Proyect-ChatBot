package com.cesde.ChatBot6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatBot6Application {

	public static void main(String[] args) {
		SpringApplication.run(ChatBot6Application.class, args);
	}

}
